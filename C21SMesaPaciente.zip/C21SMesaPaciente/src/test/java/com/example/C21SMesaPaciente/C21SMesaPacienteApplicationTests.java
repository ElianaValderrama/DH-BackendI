package com.example.C21SMesaPaciente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C21SMesaPacienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
