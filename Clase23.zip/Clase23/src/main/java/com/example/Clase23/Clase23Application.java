package com.example.Clase23;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase23Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase23Application.class, args);
	}

}
